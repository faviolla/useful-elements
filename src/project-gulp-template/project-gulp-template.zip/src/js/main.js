$(document).ready(function () {
    $('.mCustomScroll').mCustomScrollbar({
        theme: 'light-3'
    });
    // btn-up
    $(document).on("click" ,'.back-to-top' , function(e) {
        e.preventDefault();
        jQuery('html, body').animate({scrollTop: 0}, 500);
        return false;
    });
    $('.select').styler();
    $('.validate_phone').mask('+38 (999) 999 99 99');

    $(window).on('resize', function () {
        if (windowWidth < 768) {
            $('.blog-list').not('.slick-initialized').slick({
                centerMode: true,
                infinite: false,
                centerPadding: '15px',
                slidesToShow: 1,
                slidesToScroll: 1,
                swipeToSlide: true,
                touchMove: true,
                swipe: true,
                draggable: true,
                cssEase: 'linear'
            });
        } else if (windowWidth >= 768) {
            $('.blog-list.slick-initialized').slick('unslick');
        }
    }).trigger('resize');

});

$(window).scroll(function () {
    // btn-up
    if ($(this).scrollTop() > 220) {
        $('.back-to-top').fadeIn(500);
    } else {
        $('.back-to-top').fadeOut(500);
    }
});