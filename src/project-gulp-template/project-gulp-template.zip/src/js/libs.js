//= vendor/jquery-3.3.1.min.js
//= vendor/formValidate/validate.js
//= vendor/formstyler/jquery.formstyler.js
//= vendor/countdown/jquery.countdown.js
//= vendor/inputMask/jquery.inputmask.js